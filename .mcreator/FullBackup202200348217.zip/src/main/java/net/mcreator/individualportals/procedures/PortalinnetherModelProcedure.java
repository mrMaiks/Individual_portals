package net.mcreator.individualportals.procedures;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.minecraft.util.ResourceLocation;

import net.mcreator.individualportals.entity.PortalinnetherEntity;

//modified for 1.16.5, use at your own risk
public class PortalinnetherModelProcedure extends AnimatedGeoModel<PortalinnetherEntity.CustomEntity> {
	@Override
	public ResourceLocation getAnimationFileLocation(PortalinnetherEntity.CustomEntity entity) {
		return new ResourceLocation("individual_portals", "animations/portal.animation.json");
	}

	@Override
	public ResourceLocation getModelLocation(PortalinnetherEntity.CustomEntity entity) {
		return new ResourceLocation("individual_portals", "geo/portal.geo.json");
	}

	@Override
	public ResourceLocation getTextureLocation(PortalinnetherEntity.CustomEntity entity) {
		return new ResourceLocation("individual_portals", "textures/entities/portals.png");
	}
	/**
	@Override
	public void setCustomAnimations(PortalinnetherEntity.CustomEntity animatable, int instanceId, AnimationEvent animationEvent) {
	super.setCustomAnimations(animatable, instanceId, animationEvent);
	IBone head = this.getAnimationProcessor().getBone("head");
	EntityModelData extraData = (EntityModelData) animationEvent.getExtraDataOfType(EntityModelData.class).get(0);
	AnimationData manager = animatable.getFactory().getOrCreateAnimationData(instanceId);
	head.setRotationX(head.getRotationX() + extraData.headPitch * ((float) Math.PI / 180F));
	head.setRotationY(head.getRotationY() + extraData.netHeadYaw * ((float) Math.PI / 180F));
	}
	 /** **/
}
